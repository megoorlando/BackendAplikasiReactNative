const express = require("express")
const multer = require("multer")
const MainRoute = express.Router()

const mySql = require('../database/MySql')

const storage = multer.diskStorage({
    destination(req, file, callback) {
      callback(null, './public/image');
    },
    filename(req, file, callback) {
      callback(null, `${file.fieldname}_${Date.now()}_${file.originalname}`);
    },
});
  
const upload = multer({ storage});


//get Profile
MainRoute.get('/profile/:id?', (req, res)=>{
    const {id} = req.query;
    try{
        mySql.query(
            `SELECT user_name,user_about,user_telp,	fk_city_id,user_photoprofile 
            FROM ms_login a INNER JOIN ms_user b ON a.pk_login_id  = b.fk_login_id	
            WHERE pk_login_id = ${id}`,
            (error, results, fields)=>{
                if(error) throw error;

                res.status(200).json({
                    message: 'success!',
                    data:results
                });
            })
    }catch{
        res.status(500).send();
    }
})


//Post Item
MainRoute.post(
    '/PostItem/:id?', 
    (req, res)=>{
        const {id} = req.query;
        const {name,category, price,description,photo} = req.body;
        try{ 
            mySql.query(
                `INSERT INTO ms_photo_item(photo_item_name)
                Values('${photo}')`, 
                (error, results, fields)=>{
                    if(error) throw error;
    
                    console.log(results.insertId)   //hasil pk_item_id
    
                    //GENERATE QUERY
                    let query = `INSERT INTO ms_item(item_name,item_price,item_description,fk_category_id,fk_user_id,fk_photo_item_id)
                    Values('${name}','${price}','${description}','${category}','${id}','${results.insertId}')
                    `
                    console.log(query)
                    
                    mySql.query(
                        query,
                        (error, results, fields)=>{
                            if(error) throw error;
    
                            res.status(200).json({
                                message: 'success!',
                            });
                        }
                    )
                    
                })}catch(err){
            res.status(500).send(err)
        }
            
    }
)

//get City
MainRoute.get('/GetCity', (req, res)=>{
    try{
        mySql.query(
            `SELECT * FROM ms_city`,
            (error, results, fields)=>{
                if(error) throw error;  
                res.status(200).json({
                    message: 'get City success!',
                    data:results
                });
            })
    }catch{
        res.status(500).send();
    }
})

// get Category

MainRoute.get('/GetCategory', (req, res)=>{
    try{
        mySql.query(
            `SELECT * FROM ms_category`,
            (error, results, fields)=>{
                if(error) throw error;  
                res.status(200).json({
                    message: 'get Category Success',
                    data:results
                });
            })
    }catch{
        res.status(500).send();
    }
})


module.exports = MainRoute