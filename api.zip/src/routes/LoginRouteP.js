const express = require("express")
const CryptoJS = require("crypto-js");
const bcrypt = require('bcrypt');
const LoginRouteP = express.Router()

const mySql = require('../database/MySql')

const secretKey = 'PikedProject'


LoginRouteP.get('/photo/:id?', (req, res)=>{
    const {id} = req.query;
    try{
        mySql.query(
            `SELECT * FROM master_userphoto WHERE user_id = ${id}`,
            (error, results, fields)=>{
                if(error) throw error;

                res.status(200).json({
                    message: 'success!',
                    data:results
                });
            })
    }catch{
        res.status(500).send();
    }
})


//daftar
LoginRouteP.post(
    '/Register', 
    (req, res)=>{
        const {name, phone, city,email,password} = req.body;
        try{ 
            mySql.query(
                `INSERT INTO ms_login (login_email,login_password)
                VALUES ('${email}','${password}') `,
                (error, results, fields)=>{
                    if(error) throw error;
    
                    console.log(results.insertId)   
    
                    //GENERATE QUERY
                    let query = `insert into ms_user(user_name, user_telp,fk_city_id,fk_login_id) 
                    VALUES ('${name}','${phone}','${city}',${results.insertId})`
    
                    console.log(query)
                    
                    mySql.query(
                        query,
                        (error, results, fields)=>{
                            if(error) throw error;
    
                            res.status(200).json({
                                message: 'success!',
                            });
                        }
                    )
                    
                })}catch(err){
            res.status(500).send(err)
        }
            
    }
)

//get City
LoginRouteP.get('/GetCity', (req, res)=>{
    try{
        mySql.query(
            `SELECT * FROM ms_city ORDER BY city_name`,
            (error, results, fields)=>{
                if(error) throw error;

                res.status(200).json({
                    message: 'get City success!',
                    data:results
                });
            })
    }catch{
        res.status(500).send();
    }
})



//login
LoginRouteP.post(
    '/Login', 
    (req, res)=>{
        const {email, password} = req.body
        try{
            mySql.query(
                `SELECT login_password FROM ms_login WHERE login_email = '${email}' `,
                
                (error, results, fields)=>{
                    if(error) throw error; 
                    let pass =results[0].login_password
                    if(password==pass){    
                        res.status(200).json({
                            message: 'Login!'
                        });
                    }else{
                        res.status('401').json({
                            message: 'Invalid Credential !!'
                        });
                    }
                })
        }catch{
            res.status(500).send();
        }
    })

module.exports = LoginRouteP