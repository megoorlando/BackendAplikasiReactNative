const express = require("express")
const storeRoute = express.Router()

storeRoute.get("/Read", (req, res)=>{
    res.send("Store Get")
})

module.exports = storeRoute